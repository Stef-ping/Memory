const letters = ["a", "a", "b", "b", "c", "c", "d", "d", "e", "e", "f", "f", "g", "g", "h", "h"];
const shuf_letters = letters.sort(() => (Math.random() > .5) ? 1 : -1);
let firstBox = null;
let secondBox = null;
let lockBoard = false;

for (let i = 0; i < letters.length; i++) {
    let box = document.createElement("div");
    box.className = "item";
    box.innerHTML = shuf_letters[i];

    box.addEventListener('click', function() {
        if (lockBoard) return;
        if (this === firstBox) return;

        this.classList.add('boxOpen');

        if (!firstBox) {
            firstBox = this;
            return;
        }

        secondBox = this;
        lockBoard = true;

        setTimeout(() => {
            if (firstBox.innerHTML === secondBox.innerHTML) {
                firstBox.classList.add('boxMatch');
                secondBox.classList.add('boxMatch');
                document.getElementById('answercount').innerHTML = document.querySelectorAll('.boxMatch').length / 2 + " goed";
                console.log(document.querySelectorAll('.boxMatch').length);
            } else {
                firstBox.classList.remove('boxOpen');
                secondBox.classList.remove('boxOpen');
            }

            firstBox = null;
            secondBox = null;
            lockBoard = false;

            if (document.querySelectorAll('.boxMatch').length === letters.length) {
                document.getElementById('answercount').innerHTML = "Gewonnen!!!";
                document.getElementById('answercount').classList.add('shake');
            }
        }, 500);
    });

    document.querySelector('.game').appendChild(box);
}
